<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'R~|;)SV}~=:f*j7b*JtF3a}=|;S[w:z{2`s.Au<~!ISaH$ftL)kF.{Zu/7olS*6I' );
define( 'SECURE_AUTH_KEY',   '().Vb}/`AQM/;^0e2T|zPz%na0hr VPbRz)(<:@?#k-J*q<[MT<m;w.J c gJpls' );
define( 'LOGGED_IN_KEY',     'C}tjT46O2<Giu}NS-jN4G8|G;U*u+P-yzF9So{_O%HSuRw.|~X9!3{$]=i&jxt43' );
define( 'NONCE_KEY',         'GPKh(:Y,QN>N2_mxbCCc:+u$wUL0N9Lw8B?U]nhR*N=?3R}2=:w0m-(5R2&#T3[=' );
define( 'AUTH_SALT',         'Rb$Xt@)0J,o:0 @GZhrT5ax&tzF(~.9aw{!8_2Kt~Y8S{9JK@F$$y9!E_*P5Bi)G' );
define( 'SECURE_AUTH_SALT',  'COvNQ$KE{~l5a`qKsplqF(?+bM^@*Uodd:(:>GH#GXlpm|B*L>c`wlzLmPwK.$,4' );
define( 'LOGGED_IN_SALT',    'I1p3x~|$3DVt^V[^9<Q/0z+vasFM]MwI[p#3<{h? IlA)s.tPNlPhbc`=f H{>)O' );
define( 'NONCE_SALT',        'nj9=d(Y&8BRYvemlm*b,7:=t7T3p^`O&+)0@P|5@PNHYn;3S#,_4^`H;UzNSB[&-' );
define( 'WP_CACHE_KEY_SALT', 'j7[o%[]a6!2JsD-fte#e/})f~%)GUoPcQn6wq&Xv{oa^3vFb)1?we eqTb^rJlpg' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
